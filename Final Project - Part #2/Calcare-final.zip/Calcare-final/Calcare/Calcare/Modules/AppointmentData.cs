﻿public class AppointmentData {
    public string PatientAHN { get; set; }
    public DateTime AppointmentStartTime { get; set; }
    public DateTime AppointmentEndTime { get; set; }
    public string Doctor { get; set; }
    public int Length { get; set; }
}
